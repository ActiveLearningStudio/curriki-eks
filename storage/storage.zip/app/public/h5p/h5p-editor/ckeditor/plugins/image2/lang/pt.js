/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'image2', 'pt', {
	alt: 'Texto alternativo',
	btnUpload: 'Enviar para o servidor',
	captioned: 'Imagem legendada',
	captionPlaceholder: 'Legenda',
	infoTab: 'Informação da imagem',
	lockRatio: 'Proporcional',
	menu: 'Propriedades da imagem',
	pathName: 'imagem',
	pathNameCaption: 'legenda',
	resetSize: 'Tamanho original',
	resizer: 'Clique e arraste para redimensionar',
	title: 'Propriedades da imagem',
	uploadTab: 'Carregar',
	urlMissing: 'O URL de origem da imagem está em falta.',
	altMissing: 'Texto alternativo em falta.'
} );
