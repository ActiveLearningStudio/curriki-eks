/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'image2', 'ug', {
	alt: 'تېكىست ئالماشتۇر',
	btnUpload: 'مۇلازىمېتىرغا يۈكلە',
	captioned: 'ماۋزۇلۇق سۈرەت',
	captionPlaceholder: 'ماۋزۇ',
	infoTab: 'سۈرەت',
	lockRatio: 'نىسبەتنى قۇلۇپلا',
	menu: 'سۈرەت خاسلىقى',
	pathName: 'رەسىم',
	pathNameCaption: 'ماۋزۇ',
	resetSize: 'ئەسلى چوڭلۇق',
	resizer: 'چېكىپ تۇرۇپ سۆرەپ چوڭ كىچىكلىكىنى تەڭشىگىلى بولىدۇ',
	title: 'سۈرەت خاسلىقى',
	uploadTab: 'يۈكلە',
	urlMissing: 'سۈرەتنىڭ ئەسلى ھۆججەت ئادرېسى كەم',
	altMissing: 'باشقا تېكىست كەمچىل'
} );
